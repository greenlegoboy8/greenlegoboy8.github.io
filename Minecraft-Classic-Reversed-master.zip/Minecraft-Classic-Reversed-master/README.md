# Minecraft Classic Reversed
This is a project meant to document the functions and code of classic.minecraft.net.

# Usage
Clone the repo and run start-server.bat, or run http-server on the working directory.
Then, connect to the server using localhost:8080 in your preferred browser.

# Takedown

This is meant as a fun project. If I must take it down due to legal reasons,
please contact me at thesuncat123@gmail.com, or on Discord at TheSunCat#1007.
